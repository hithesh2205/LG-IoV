# Privacy-Preserving Collaborative IDS for the Internet of Vehicles

**LGSI industry project — progress record**
Audit date: 2026-08-08 · Project month: 5 of 12

This folder is the from-the-start record of the project, written to be pushed to
GitHub. It is deliberately honest: it records what was built, what works, what
does not, and what was claimed in review meetings that the code does not yet
support.

## Contents

| File | What it covers |
|------|----------------|
| [01_project_overview.md](01_project_overview.md) | Problem statement, system architecture, repository map |
| [02_timeline.md](02_timeline.md) | Month-by-month record of what was actually built |
| [03_lg_gap_analysis.md](03_lg_gap_analysis.md) | Deliverable-by-deliverable status against `LG_Expectations_IDS.pdf` |
| [04_decision_audit.md](04_decision_audit.md) | Every major technical decision, judged correct / wrong / unproven |
| [05_defects.md](05_defects.md) | Confirmed defects with file:line evidence and fixes |
| [06_multikey_ckks_plan.md](06_multikey_ckks_plan.md) | FheFL (arXiv:2306.05112) adoption plan for multi-key CKKS |
| [07_recovery_plan.md](07_recovery_plan.md) | **Week-by-week plan to close the month-5 gap** — start here if you are picking up work |

## One-paragraph status

A federated intrusion-detection pipeline exists end to end: four vehicular
datasets are parsed into a shared 46-D feature space, sharded non-IID across
simulated vehicles, trained locally with a Chebyshev-polynomial KAN
(44k parameters), filtered with Multi-Krum, and aggregated. A genuine TenSEAL
CKKS benchmark measures real encryption cost. **However**, the encryption used
during training is a numpy stand-in, not encryption; the Byzantine filter
decrypts individual client updates server-side, which a real deployment cannot
do; and the CAN datasets are labelled per-file rather than per-message, which
inflates the headline accuracy numbers. The project is also running entirely in
Python on a laptop, while the LG plan expects embedded/hardware work by month 5.
The pivot to multi-key CKKS is the right next research step but does not close
the month-5 schedule gap.

## Quick reproduction

From `Team/LG_IoV/NewModel`:

```bash
python train_federated.py --dataset can_vtc
```

```bash
python benchmark_real_ckks.py
```
